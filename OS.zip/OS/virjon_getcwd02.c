/* Virginija Jonušaitė IFIN-7/4 virjon */
/* failas: virjon_pathconf.c */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int test_getcwd();

int test_getcwd()
{
	char *cwd;
	cwd = getcwd( NULL, pathconf( ".", _PC_PATH_MAX) );
	puts( cwd );
	free( cwd );
	
	int dskr;
	dskr = open( cwd, O_RDONLY );
	printf("%d\n", dskr);
	
	chdir( "/tmp" );
	
	cwd = getcwd( NULL, pathconf( ".", _PC_PATH_MAX) );
	puts( cwd );
	
	fchdir(dskr);
	
	cwd = getcwd( NULL, pathconf( ".", _PC_PATH_MAX) );
	puts( cwd );
	
	return 1;
}

int main()
{
	test_getcwd();
	return 0;
}