/* Virginija Jonušaitė IFIN-7/4 virjon */
/* failas: virjon_pathconf.c */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>

int create();

int create()
{
	int fd;
	char *filename = "fai55las";
	fd = creat(filename, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	if(fd != -1)
		printf("Failas sukurtas sekmingai\n");
	else 
		return 1;
}

int main() 
{
	create();
	return 0;
}
