/* Virginija Jonušaitė IFIN-7/4 virjon */
/* failas: virjon_pathconf.c */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>

int main(){
	
	DIR *dir = opendir( "." );
	struct dirent *dp;
	
	while ( (dp = readdir(dir)) != NULL )
		printf("Node numers %d Vardas %s \n", dp->d_ino, dp->d_name);
	closedir(dir);
	return 0;
}