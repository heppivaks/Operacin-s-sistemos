#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int open1(const char *name);

int open1(const char *name){
	
   int dskr;
   dskr = open( name, O_RDONLY );
   if( dskr == -1 )
   {
      perror( name );
      exit(1);
   }
   printf( "dskr = %d\n", dskr );
   return dskr;
   
}

int open2(const char *name);

int open2(const char *name){
	
   int dskr;
   dskr = open( name, O_WRONLY | O_CREAT | O_TRUNC, 0640 );
   
   if( dskr == -1 )
   {
      perror( name );
      exit(1);
   }
   printf( "dskr = %d\n", dskr );
   return dskr;
   
}

int close1(int fd);

int close1(int fd){

   int rv;
   rv = close( fd );
   
   if( rv != 0 ) perror ( "uždarymas nepavyko" );
   else puts( "uždarytas pavyko" );
   return rv

}

int main( int argc, char *argv[] ){

   char duomenys[1000000];
   
   if( argc != 4  )
   {
      printf( "Netinkamas argumentų kiekis\n" );
      exit( 255 );
   }
   int nbytes = atoi(argv[3]);
   int d1 = open1( argv[1] );
   int d2 = open2( argv[2] );
   
   int nuskaitymas = read( d1, duomenys, nbytes );
   write(d2, duomenys, nbytes );
   
   printf("Nuskaitytų ir įrašytų baitų kiekis: %ld\n", nuskaityta);
   
   close1( d1 );
   close1( d2 );
   return 0;
}