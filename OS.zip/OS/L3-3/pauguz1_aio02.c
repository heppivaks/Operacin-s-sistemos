#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <aio.h>
#define BUFFLEN 1048576

int open1(const char *name);

int open1(const char *name){
	
   int dskr;
   dskr = open( name, O_RDONLY );
   
   if( dskr == -1 )
   { 
      perror( name );
      exit(1);
   }
   printf( "dskr = %d\n", dskr );
   return dskr;
   
}

int open2(const char *name);

int open2(const char *name){
	
   int dskr;
   dskr = open( name, O_WRONLY | O_CREAT | O_TRUNC , 0640);
   
   if( dskr == -1 )
   {
      perror( name );
      exit(1);
   }
   printf( "dskr = %d\n", dskr );
   return dskr;
   
}

int close1(int fd);

int close1(int fd){

   int rv;
   rv = close( fd );
   
   if( rv != 0 ) perror ( "uždarymas nepavyko" );
   else puts( "uždarymas pavyko" );
   return rv;

}

int test_aio_read_start( const int d, struct aiocb *aiorp, void *buf, const int count );

int test_aio_read_start( const int d, struct aiocb *aiorp, void *buf, const int count )
{
   int rv = 0;
   memset( (void *)aiorp, 0, sizeof( struct aiocb ) );
   
   aiorp->aio_fildes = d; // -> skaitom
   aiorp->aio_buf = buf; // -> rašom
   aiorp->aio_nbytes = count; // -> kiekis
   aiorp->aio_offset = 0; // -> nuo kur
   
   rv = aio_read( aiorp );
   if( rv != 0 ){
      perror( "aio_read failed" );
      abort();
   }
   return rv;
}

int test_aio_read_waitcomplete( struct aiocb *aiorp );

int test_aio_read_waitcomplete( struct aiocb *aiorp )
{
   const struct aiocb *aioptr[1];
   int rv;
   aioptr[0] = aiorp;
   rv = aio_suspend( aioptr, 1, NULL );
   if( rv != 0 ){
      perror( "aio_suspend failed" );
      abort();
   }
   rv = aio_return( aiorp );
   printf( "AIO complete, %d bytes read.\n", rv );
   return 1;
}

int main( int argc, char * argv[] )
{
   struct aiocb aior;
   char buffer[BUFFLEN];
   int d = open1( "atsitiktiniai_duomenys_1MB" );
   int f = open2( "bandymas");
   
   int bytes_read = 0;
   
   while (bytes_read != 1000000)
   {
   test_aio_read_start( d, &aior, buffer, 100000 );
   test_aio_read_waitcomplete( &aior );
   
   write(f, buffer, 100000);
   
   bytes_read = bytes_read + 100000;
   
   lseek(d, bytes_read, SEEK_SET);
   lseek(f, bytes_read, SEEK_SET);
   }
   
   close1( d );
   close1( f );
   return 0;
}
