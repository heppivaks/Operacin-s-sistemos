#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int open1(const char *name);

int open1(const char *name){
   int dskr;
   
   dskr = open( name, O_RDWR | O_CREAT | O_TRUNC, 0640 );
   
   if( dskr == -1 )
   {
      perror( name );
      exit(1);
   }
   printf( "dskr = %d\n", dskr );
   
   return dskr; 
}

int close1(int fd);

int close1(int fd){

   int rv;
   rv = close( fd );
   
   if( rv != 0 ) perror ( "uždarymas nepavyko" );
   else puts( "uždarymas pavyko" );
   
   return rv;
}

int main( int argc, char *argv[] ){
	
   char data[1] = "a";
   
   if( argc != 2  ) 
   {
      printf( "Turi buti nurodytas failas\n" );
      exit( 255 );
   }
   
   int desk = open1( argv[1] );
   lseek(desk,1000000,SEEK_SET);
   write(desk,data,1);
   close1( desk );
   return 0;

}