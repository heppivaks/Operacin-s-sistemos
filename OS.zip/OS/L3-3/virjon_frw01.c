#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main( int argc, char *argv[] ){

   char duomenys[1000000];
   int nbytes = atoi(argv[3]);
   
   if( argc != 3  ) // jeigu nurodyti ne keturi argumentai
   {
      printf( "Nepakankamas argumentų kiekis\n" );
      exit( 255 );
   }
   FILE *fd = fopen( argv[1], "r" );
   FILE *fr = fopen( argv[2], "w" );
   
   int nuskaityta = fread( duomenys, nbytes, 1, fd );
   fwrite( duomenys, nbytes, 1, fr );
   
   printf("Nuskaitytų ir įrašytų argumentų kiekis: %ld\n", nuskaityta);
   
   fclose( fd );
   fclose( fr );
   return 0;

}