/* Virginija Jonušaitė IFIN-7/4 virjon */
/* failas: virjon_pathconf.c */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/statvfs.h>
#include <ftw.h>

int failai (const char *p, const struct stat *st, int aa, struct FTW *fbuf);

int failai (const char *p, const struct stat *st, int aa, struct FTW *fbuf)
{
	if (aa == FTW_F)
	printf(p);
	return 0;
}

int main()
{
	nftw("/export/home/virjon", failai, 1000, FTW_PHYS);
	return 0;
}