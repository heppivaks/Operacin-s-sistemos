#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/resource.h>
 
int main( int argc,char * argv[] ){
	
   struct rlimit r1;
   struct rlimit r2;
   getrlimit (RLIMIT_CPU, &r1);
   
   printf("\n Cpu limitas : %lld\n", (long long int)r1.rlim_cur);
 
   r1.rlim_cur = 1;
   setrlimit (RLIMIT_CPU, &r1);
   getrlimit (RLIMIT_CPU, &r1);
 
   printf("\n Cpu limitas : %lld\n", (long long int)r1.rlim_cur);
   
   getrlimit (RLIMIT_CORE, &r2);
	
   printf("\n Core limitas : %lld\n", (long long int)r2.rlim_cur);
	
   r2.rlim_cur = 0;
   setrlimit (RLIMIT_CORE, &r2);
   getrlimit (RLIMIT_CORE, &r2);
	
   printf("\n Core limitas : %lld\n", (long long int)r2.rlim_cur);
	
   int cnt = 1;
   while (1) 
   {
       printf("%d \n", cnt);
	   cnt ++;
   }
   
   return 0;
}