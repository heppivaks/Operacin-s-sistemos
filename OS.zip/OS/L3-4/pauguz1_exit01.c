#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/resource.h>

void funkcija1()
{
	printf("f1\n");
}
void funkcija2()
{
    printf("f2\n");
}
void funkcija3()
{
    printf("f3\n");
}

int main( int argc, char * argv[] ){

   atexit(funkcija1);
   atexit(funkcija2);
   atexit(funkcija3);
   return 0;
}
