#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/stat.h>
 
int atidaryti(){
   int dskr;
   dskr = open( "./data.bin", O_RDWR );
   if( dskr == -1 ){
      exit(1);
   }
   printf( "Failo deskriptorius = %d\n", dskr );
   return dskr;
}
 
int main( int argc, char *argv[] ){
    struct stat st;
    int d, size, bytes;
	
    if (argc != 2)
    {
        printf("Nurodytas netinkamas kiekis argumentų, programa uždaroma\n");
        exit(1);
    }
	
    if ((bytes = atoi(argv[1])) < 0)
    {
        printf("Argumentu reikia nurodyti sveiką, teigiamą skaičių, programa uždaroma\n");
        exit(1);
    }
	
    d = atidaryti();
	
    stat("./data.bin", &st);
    size = st.st_size;
	
    if (size <= bytes)
    {
        printf("Failo dydis didesnis nei nuordytas baitų kiekis\n");
        exit(1);
    }
	
    char bc[size - bytes];
	
    if (pread(d, bc, sizeof(bc), bytes) != -1)
        printf("Nuskaitymas nuo nurodyto baito - sėkmingas!\n");
   
    if (pwrite(d, bc, bytes, 0) != -1)
        printf("Kopijavimas sėkmingas! Nukopijuota baitų: %d\n", bytes);
   
    if (close(d) == 0)
        printf("Failas uždarytas sėkmingai!\n");
    return 0;
}